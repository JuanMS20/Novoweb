<template>
    <footer>
        <p>&copy; 2024 novo. All rights reserved.</p>
        <nav>
        <a href="#">Terms of Service</a>
        <a href="#">Privacy</a>
        </nav>
    </footer>
</template>
<style scoped>
footer {
    background-color: #f5f5f5;
    padding: 1rem;
    text-align: center;
    font-size: 0.9rem;
  }
  
  footer nav {
    margin-top: 0.5rem;
  }
  
  footer a {
    margin: 0 0.5rem;
    color: #666;
    text-decoration: none;
  }
  
  h2 {
    text-align: center;
    font-size: 2rem;
    margin-bottom: 2rem;
  }
  
  .sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border-width: 0;
  }
</style>