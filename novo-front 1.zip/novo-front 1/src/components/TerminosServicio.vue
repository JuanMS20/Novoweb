<template>
    <div class="terms-service">
      <section class="terms-header">
        <h1>Términos y Condiciones de Servicio</h1>
        <p>Última actualización: 14 de Noviembre, 2024</p>
      </section>
  
      <section class="terms-content">
        <h2>1. Aceptación de los Términos</h2>
        <p>
          Al acceder o utilizar los servicios de <strong>NOVO</strong> (en adelante, "nosotros", "la página web", "el servicio"), usted acepta cumplir con estos términos y condiciones, incluyendo cualquier modificación que se haga a estos en el futuro. Si no está de acuerdo con alguno de los términos de este acuerdo, no utilice nuestros servicios.
        </p>
  
        <h2>2. Definiciones</h2>
        <p>
          En estos términos y condiciones, las siguientes palabras tienen los siguientes significados:
        </p>
        <ul>
          <li><strong>"Usuario"</strong>: Cualquier persona que acceda o utilice el servicio.</li>
          <li><strong>"Producto"</strong>: Cualquier artículo que se ofrezca para la compra, venta o intercambio en la página web.</li>
          <li><strong>"Plataforma"</strong>: El sitio web y todas sus funcionalidades asociadas que permiten la interacción entre compradores y vendedores.</li>
          <li><strong>"Contenido"</strong>: Toda la información, imágenes, productos, datos, textos, videos, etc., subidos, publicados o mostrados a través del servicio.</li>
        </ul>
  
        <h2>3. Uso del Servicio</h2>
        <p>
          Usted se compromete a utilizar el servicio exclusivamente para fines legales, y no utilizarlo para publicar contenido que sea:
        </p>
        <ul>
          <li>Difamatorio, obsceno, discriminatorio, o que incite a la violencia o discriminación.</li>
          <li>Fraudulento o que infrinja derechos de propiedad intelectual de terceros.</li>
          <li>Que cause daños, interrupciones o interrupciones a nuestro sistema o infraestructura tecnológica.</li>
        </ul>
  
        <h2>4. Registro de Cuenta</h2>
        <p>
          Para acceder a ciertas funcionalidades de la plataforma, es posible que se requiera crear una cuenta. Al crear una cuenta, usted se compromete a proporcionar información precisa, actualizada y completa. Usted es responsable de mantener la confidencialidad de su cuenta y contraseñas, y acepta que notificará de inmediato cualquier uso no autorizado de su cuenta.
        </p>
  
        <h2>5. Propiedad Intelectual</h2>
        <p>
          Todos los derechos de propiedad intelectual sobre el contenido, diseño, logos, marcas comerciales y cualquier otro material relacionado con la plataforma son propiedad exclusiva de <strong>NOVO</strong> o sus licenciatarios. Queda prohibido el uso, copia, distribución o modificación de dicho contenido sin la autorización expresa de <strong>NOVO</strong>.
        </p>
  
        <h2>6. Manejo de Información Personal</h2>
        <p>
          Al utilizar el servicio, usted acepta el tratamiento de su información personal según lo dispuesto en nuestra Política de Privacidad, que está disponible en el siguiente enlace: <router-link to="/privacidad">Política de Privacidad</router-link>. Esto incluye la recopilación, almacenamiento, uso y posible divulgación de sus datos personales para ofrecer nuestros servicios, mejorar la experiencia de usuario y cumplir con las leyes aplicables.
        </p>
  
        <h2>7. Responsabilidad del Usuario</h2>
        <p>
          El usuario es el único responsable de todo el contenido que cargue, publique o comparta a través de la plataforma. Nos reservamos el derecho de eliminar cualquier contenido que no cumpla con estos términos, sin previo aviso. El usuario también acepta indemnizar y eximir de responsabilidad a <strong>NOVO</strong> por cualquier reclamo, daño o pérdida derivados del uso de la plataforma, incluidas las demandas de terceros relacionadas con el contenido publicado por el usuario.
        </p>
  
        <h2>8. Publicación de Productos</h2>
        <p>
          Al publicar productos para su compra o venta, usted declara que tiene los derechos necesarios sobre los mismos, que son legales y cumplen con las normativas aplicables. <strong>NOVO</strong> no es responsable de la calidad, seguridad o legalidad de los productos publicados.
        </p>
        <p>
          Nos reservamos el derecho de eliminar productos que infrinjan estos términos, sin necesidad de notificación previa.
        </p>
  
        <h2>9. Transacciones y Pagos</h2>
        <p>
          <strong>NOVO</strong> proporciona una plataforma para facilitar las transacciones entre compradores y vendedores, pero no es responsable de la ejecución de las transacciones. Todos los pagos deben realizarse a través de nuestro sistema seguro de pagos, utilizando el medio autorizado (Nequi).
        </p>
        <p>
          Al realizar una transacción, usted acepta que los pagos y productos serán gestionados bajo los términos acordados entre las partes, y que cualquier disputa será resuelta directamente entre el comprador y el vendedor.
        </p>
  
        <h2>10. Modificaciones de los Términos</h2>
        <p>
          Nos reservamos el derecho de modificar estos términos en cualquier momento, con efecto inmediato a partir de la publicación de la versión actualizada en nuestro sitio web. Es su responsabilidad revisar periódicamente estos términos para estar al tanto de las modificaciones. Su uso continuo del servicio después de cualquier cambio implica su aceptación de los nuevos términos.
        </p>
  
        <h2>11. Exención de Responsabilidad</h2>
        <p>
          <strong>NOVO</strong> no garantiza que el servicio esté libre de interrupciones, errores o que sea seguro en todo momento. No nos hacemos responsables de cualquier daño directo, indirecto, incidental, especial o consecuente que pueda surgir del uso o la incapacidad de usar la plataforma, incluidos los daños por pérdida de datos o interrupciones en el servicio.
        </p>
  
        <h2>12. Limitación de Responsabilidad</h2>
        <p>
          En ningún caso, nuestra responsabilidad total hacia usted por todos los daños o pérdidas derivadas de o en conexión con el uso de los servicios, excederá el monto que usted haya pagado por los productos o servicios adquiridos a través de la plataforma en los 12 meses anteriores.
        </p>
  
        <h2>13. Ley Aplicable y Jurisdicción</h2>
        <p>
          Estos términos se rigen por las leyes del país en el que operamos, y cualquier disputa relacionada con el uso de la plataforma será resuelta ante los tribunales competentes en la ciudad donde está registrada nuestra empresa.
        </p>
  
        <h2>14. Política de Cookies</h2>
        <p>
          Al utilizar nuestra plataforma, usted acepta el uso de cookies. Las cookies son pequeños archivos que se almacenan en su dispositivo para mejorar la experiencia de usuario. Puede modificar la configuración de su navegador para rechazar cookies, pero esto puede afectar su capacidad de usar ciertas funciones de la plataforma.
        </p>
  
        <h2>15. Terminación de la Cuenta</h2>
        <p>
          <strong>NOVO</strong> se reserva el derecho de suspender o eliminar la cuenta de cualquier usuario que viole estos términos y condiciones, sin previo aviso. La suspensión o eliminación de una cuenta no exime al usuario de sus obligaciones legales, incluidas las responsabilidades financieras pendientes.
        </p>
  
        <h2>16. Cláusulas Generales</h2>
        <p>
          Estos términos constituyen el acuerdo completo entre el usuario y <strong>NOVO</strong> con respecto al uso del servicio. Si alguna disposición de estos términos es declarada inválida o inaplicable, las disposiciones restantes seguirán siendo válidas y aplicables.
        </p>
      </section>
    </div>
  </template>
  
  <script setup>
  // Aquí puedes importar cualquier componente si lo necesitas, como iconos o algo para el diseño
  </script>
  
  <style scoped>
  .terms-service {
    padding: 20px;
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4;
  }
  
  .terms-header {
    text-align: center;
    margin-bottom: 30px;
  }
  
  .terms-header h1 {
    font-size: 36px;
    color: #333;
  }
  
  .terms-header p {
    font-size: 18px;
    color: #666;
  }
  
  .terms-content {
    font-size: 16px;
    color: #333;
  }
  
  .terms-content h2 {
    font-size: 24px;
    margin-top: 40px;
    color: #3498db;
  }
  
  .terms-content ul {
    list-style-type: none;
    padding-left: 0;
  }
  
  .terms-content li {
    margin-bottom: 10px;
  }
  </style>
  